interface ShapesInterface{
    double getHeight();
    double getLength();
    double getRadiusSquared();
    double getRadius();
    double getSide2();
}

//Circle = radius squared * Pi
//Sphere = 4 * Pi * r * r
//Parallelogram = l x h

public class Shapes implements ShapesInterface {
    double height, length, radius, side2;
    final double pi = 3.1416;

    public Shapes(){
        height = 0;
        length = 0;
        radius = 0;
        side2 = 0;
    }

    public Shapes(double height, double length, double radius, double side2){
        this.height = height;
        this.length = length;
        this.radius = radius;
        this.side2 = side2;
    }

    @Override
    public double getHeight() {
        return height;
    }
    @Override
    public double getLength() {
        return length;
    }
    @Override
    public double getRadiusSquared(){
        return radius * radius;
    }
    @Override
    public double getRadius(){
        return radius;
    }
    @Override
    public double getSide2(){
        return side2;
    }
}