public class Parallelogram extends Shapes{
    public Parallelogram(){
        super();
    }

    public Parallelogram(double height, double length, double radius, double side2){
        super(height, length, radius, side2);
    }

    protected double areaParallelogram(){
        return (getHeight() * getLength());
    }

    protected double perParallelogram(){
        return ((getLength() + getHeight()) * 2);
    }
    protected String areaAndPer(){
        return "The area & perimeter of the Parallelogram is : " + areaParallelogram() + ", " + perParallelogram();
    }
}
