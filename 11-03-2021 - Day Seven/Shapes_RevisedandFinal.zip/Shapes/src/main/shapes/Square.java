public class Square extends Shapes{
    public Square(double height, double length){
        super(height, length);
    }

    public double areaSquare(){
        if (getHeight() != getLength()){
            System.out.println("Invalid parameters. Squares must have equal sides!");
            return (0);
        }
        else {
            return (getHeight() * getLength());
        }
    }

    protected double perSquare(){
        return (getHeight() * 4);
    }

    protected String areaAndPer(){
        return "The area & perimeter of the Square is : " + areaSquare() + ", " + perSquare();
    }
}
