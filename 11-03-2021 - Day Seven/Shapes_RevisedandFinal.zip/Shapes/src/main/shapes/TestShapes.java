public class TestShapes {
    public static void main(String[] args){
        double a = 5.5; //Height
        double b = 5.5; //Length
        double c = 3.3; //Radius
        double d = 5;   //Side 2
        Triangle ObjTriangle = new Triangle (a, b, d);
        Square ObjSquare = new Square (a, b);
        Rectangle ObjRectangle = new Rectangle (a, b);
        Circle ObjCircle = new Circle (c);
        Parallelogram ObjParallelogram = new Parallelogram(a, b);
        Sphere ObjSphere = new Sphere(c);

        System.out.println(ObjCircle.areaAndPer() + " \n" +
                ObjParallelogram.areaAndPer() + " \n" +
                ObjTriangle.areaAndPer() + " \n" +
                ObjRectangle.areaAndPer() + " \n" +
                ObjSphere.areaAndPer() + " \n" +
                ObjSquare.areaAndPer() + " \n" +
                ObjTriangle.areaAndPer() +
                "\n___________________________________________________________________" +
                "\nHeight, Length, *Side 2, & Radius: " + a + ", " + b + ", " + d + ", " + c +
                "\nRadius Doubled: " + ObjCircle.getRadiusSquared() +
                "\nPi: " + ObjTriangle.pi
        );
    }
}
