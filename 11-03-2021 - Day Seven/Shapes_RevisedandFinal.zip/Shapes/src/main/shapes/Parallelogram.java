public class Parallelogram extends Shapes{
    public Parallelogram(double height, double length){
        super(height, length);
    }

    protected double areaParallelogram(){
        return (getHeight() * getLength());
    }

    protected double perParallelogram(){
        return ((getLength() + getHeight()) * 2);
    }
    protected String areaAndPer(){
        return "The area & perimeter of the Parallelogram is : " + areaParallelogram() + ", " + perParallelogram();
    }
}
