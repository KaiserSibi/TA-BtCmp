public class Square extends Shapes{
    public Square(double height, double length, double radius, double side2){
        super(height, length, radius, side2);
    }

    public double areaSquare(){
        if (getHeight() != getLength()){
            System.out.println("Invalid parameters. Squares must have equal sides!");
            return (0);
        }
        else {
            return (getHeight() * getLength());
        }
    }

    protected double perSquare(){
        return (getHeight() * 4);
    }

    protected String areaAndPer(){
        return "The area & perimeter of the Square is : " + areaSquare() + ", " + perSquare();
    }
}
