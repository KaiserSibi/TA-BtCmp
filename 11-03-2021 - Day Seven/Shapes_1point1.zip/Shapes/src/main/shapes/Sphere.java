public class Sphere extends Shapes{
    public Sphere(double height, double length, double radius, double side2){
        super(height, length, radius, side2);
    }

    protected double areaSphere(){
        return ((pi * 4) * getRadiusSquared());
    }

    protected double perSphere(){
        return ((pi * 2) * getRadius());
    }

    protected String areaAndPer(){
        return "The area & perimeter of the Sphere is : " + areaSphere() + ", " + perSphere();
    }
}
