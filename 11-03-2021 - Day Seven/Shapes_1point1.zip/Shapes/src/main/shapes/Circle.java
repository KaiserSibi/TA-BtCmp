public class Circle extends Shapes{
    public Circle(double height, double length, double radius, double side2){
        super(height, length, radius, side2);
    }

    protected double areaCircle(){
        return (getRadiusSquared() * pi);
    }

    protected double perCircle(){
        return (getRadius() * (2 * pi));
    }

    protected String areaAndPer(){
        return "The area & perimeter of the Circle is : " + areaCircle() + ", " + perCircle();
    }
}