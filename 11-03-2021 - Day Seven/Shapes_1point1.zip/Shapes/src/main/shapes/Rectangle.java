public class Rectangle extends Shapes{
    public Rectangle(double height, double length, double radius, double side2){
        super(height, length, radius, side2);
    }
    protected double areaRectangle(){
        return (getHeight() * getLength());
    }
    protected double perRectangle(){
        return ((getHeight() + getLength()) * 2);
    }

    protected String areaAndPer(){
        return "The area & perimeter of the Rectangle is : " + areaRectangle() + ", " + perRectangle();
    }
}