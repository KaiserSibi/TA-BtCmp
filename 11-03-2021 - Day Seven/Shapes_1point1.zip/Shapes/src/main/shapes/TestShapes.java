public class TestShapes {
    public static void main(String[] args){
        double a = 5.5;
        double b = 5.5;
        double c = 3.3;
        double d = 5;
        Triangle ObjTriangle = new Triangle (a, b, c, d);
        Square ObjSquare = new Square (a, b, c, d);
        Rectangle ObjRectangle = new Rectangle (a, b, c, d);
        Circle ObjCircle = new Circle (a, b, c, d);
        Parallelogram ObjParallelogram = new Parallelogram(a, b, c, d);
        Sphere ObjSphere = new Sphere(a, b, c, d);

        System.out.println(ObjCircle.areaAndPer() + " \n" +
                ObjParallelogram.areaAndPer() + " \n" +
                ObjTriangle.areaAndPer() + " \n" +
                ObjRectangle.areaAndPer() + " \n" +
                ObjSphere.areaAndPer() + " \n" +
                ObjSquare.areaAndPer() + " \n" +
                ObjTriangle.areaAndPer() +
                "\n___________________________________________________________________" +
                "\nHeight, Length, *Side 2, & Radius: " + a + ", " + b + ", " + d + ", " + c +
                "\nRadius Doubled: " + ObjCircle.getRadiusSquared() +
                "\nPi: " + ObjTriangle.pi
        );
    }
}
