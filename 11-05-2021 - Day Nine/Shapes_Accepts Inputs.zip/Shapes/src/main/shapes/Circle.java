public class Circle extends Shapes{

    Circle(double radius) {
        super(radius);
    }
    protected double areaCircle(){
        return (getRadiusSquared() * pi);
    }

    protected double perCircle(){
        return (radius * (2 * pi));
    }

    protected String areaAndPer(){
        return "  The area & perimeter of the Circle is : " + df.format(areaCircle()) + ", " + df.format(perCircle());
    }
}