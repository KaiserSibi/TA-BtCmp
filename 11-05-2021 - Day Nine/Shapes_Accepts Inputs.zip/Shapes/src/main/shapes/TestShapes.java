import java.util.Scanner;

public class TestShapes {
    public static char menu(){
        Scanner scan = new Scanner(System.in);
        System.out.println("\no=================================o");
        System.out.println("| Circle                   | C    |");
        System.out.println("| Parallelogram            | P    |");
        System.out.println("| Rectangle                | R    |");
        System.out.println("| Sphere                   | S    |");
        System.out.println("| Square                   | Q    |");
        System.out.println("| Triangle                 | T    |");
        System.out.println("| EXIT                     | X    |");
        System.out.println("o---------------------------------o\n");
        System.out.print("  Enter key to select shape: ");
        return scan.next().charAt(0);
    }
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        double a, b, c, d;  //Height, Length, *Side 2, & Radius
        char charSelected = menu();
        switch(charSelected){
            case 'C':
            case 'c':
                System.out.println("  Enter dimensions of the following dimensions     ");
                System.out.print("  Radius:   ");
                c = scan.nextDouble();
                Circle ObjCircle = new Circle (c);
                System.out.println(ObjCircle.areaAndPer());
                main(null);
                break;
            case 'P':
            case 'p':
                System.out.println("  Enter dimensions of the following dimensions     ");
                System.out.print("  Height:   ");
                a = scan.nextDouble();
                System.out.print("  Length:   ");
                b = scan.nextDouble();
                Parallelogram ObjParallelogram = new Parallelogram(a, b);
                System.out.println(ObjParallelogram.areaAndPer());
                main(null);
                break;
            case 'R':
            case 'r':
                System.out.println("  Enter dimensions of the following dimensions     ");
                System.out.print("  Height:   ");
                a = scan.nextDouble();
                System.out.print("  Length:   ");
                b = scan.nextDouble();
                Rectangle ObjRectangle = new Rectangle (a, b);
                System.out.println(ObjRectangle.areaAndPer());
                main(null);
                break;
            case 'S':
            case 's':
                System.out.println("  Enter dimensions of the following dimensions     ");
                System.out.print("  Radius:   ");
                c = scan.nextDouble();
                Sphere ObjSphere = new Sphere(c);
                System.out.println(ObjSphere.areaAndPer());
                main(null);
                break;
            case 'Q':
            case 'q':
                System.out.println("  Enter dimensions of the following dimensions     ");
                System.out.print("  Side 1:   ");
                a = scan.nextDouble();
                b = a;
                Square ObjSquare = new Square(a, b);
                System.out.println(ObjSquare.areaAndPer());
                main(null);
                break;
            case 'T':
            case 't':
                System.out.println("  Enter dimensions of the following dimensions     ");
                System.out.print("  Height:   ");
                a = scan.nextDouble();
                System.out.print("  Length:   ");
                b = scan.nextDouble();
                System.out.print("  Side 2:   ");
                d = scan.nextDouble();
                Triangle ObjTriangle = new Triangle (a, b, d);
                System.out.println(ObjTriangle.areaAndPer());
                main(null);
                break;
            case 'X':
            case 'x':
                break;
            default:
                System.out.println("  No corresponding function. Try again!");
                main(null);
                break;
        }
    }
}
