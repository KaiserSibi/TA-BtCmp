import java.text.DecimalFormat;
interface ShapesInterface{
    double getHeight();
    double getLength();
    double getRadiusSquared();
    double getRadius();
    double getSide2();
}

//Circle = radius squared * Pi
//Sphere = 4 * Pi * r * r
//Parallelogram = l x h

public class Shapes implements ShapesInterface {
    double height, length, radius, side2;
    protected static final DecimalFormat df = new DecimalFormat("0.00");
    final double pi = 3.1416;

    Shapes(double height, double length, double side2){
        this.height = height;
        this.length = length;
        this.side2 = side2;
    }
    Shapes (double height, double length){
        this.height = height;
        this.length = length;
    }
    Shapes(double radius){
        this.radius = radius;
    }

    @Override
    public double getHeight() {
        return height;
    }
    @Override
    public double getLength() {
        return length;
    }
    @Override
    public double getRadiusSquared(){
        return getRadius() * getRadius();
    }
    @Override
    public double getRadius(){
        return radius;
    }
    @Override
    public double getSide2(){
        return side2;
    }
}