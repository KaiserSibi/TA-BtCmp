public class Rectangle extends Shapes{
    public Rectangle(double height, double length){
        super(height, length);
    }
    protected double areaRectangle(){
        return (getHeight() * getLength());
    }
    protected double perRectangle(){
        return ((getHeight() + getLength()) * 2);
    }

    protected String areaAndPer(){
        return "  The area & perimeter of the Rectangle is : " + areaRectangle() + ", " + perRectangle();
    }
}