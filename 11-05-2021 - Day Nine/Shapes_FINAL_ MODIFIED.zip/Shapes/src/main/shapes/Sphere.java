public class Sphere extends Shapes{
    public Sphere(double radius){
        super(radius);
    }
    protected double areaSphere(){
        return ((pi * 4) * getRadiusSquared());
    }

    protected double perSphere(){
        return (getRadius() * 2);
    }

    protected String areaAndPer(){
        return "  The area & perimeter of the Sphere is : " + df.format(areaSphere()) + ", " + df.format(perSphere());
    }
}
