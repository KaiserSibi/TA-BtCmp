import java.util.InputMismatchException;
import java.util.Scanner;

public class TestShapes {
    public static final Scanner scan = new Scanner(System.in);
    public static char menu(){
        System.out.println("\no=================================o");
        System.out.println("| Circle                   | C    |");
        System.out.println("| Parallelogram            | P    |");
        System.out.println("| Rectangle                | R    |");
        System.out.println("| Sphere                   | S    |");
        System.out.println("| Square                   | Q    |");
        System.out.println("| Triangle                 | T    |");
        System.out.println("| EXIT                     | X    |");
        System.out.println("o---------------------------------o\n");
        System.out.print("  Enter key to select shape: ");
        return scan.next().charAt(0);
    }
    public static void main(String[] args){
        //Height, Length, *Side 2, & Radius --- double a, b, c, d;
        char charSelected = menu();
        switch(charSelected){
            case 'C':
            case 'c':
                circle();
                main(null);
                break;
            case 'P':
            case 'p':
                parallelogram();
                break;
            case 'R':
            case 'r':
                rectangle();
                break;
            case 'S':
            case 's':
                sphere();
                break;
            case 'Q':
            case 'q':
                square();
                break;
            case 'T':
            case 't':
                triangle();
                break;
            case 'X':
            case 'x':
                break;
            default:
                System.out.println("  No corresponding function. Try again!");
                main(null);
                break;
        }
    }

    // methods
    private static void parallelogram() {
        try {
            System.out.println("  Enter dimensions of the following dimensions     ");
            System.out.print("  Height:   ");
            double a = scan.nextDouble();
            System.out.print("  Length:   ");
            double b = scan.nextDouble();
            Parallelogram ObjParallelogram = new Parallelogram(a, b);
            System.out.println(ObjParallelogram.areaAndPer());
            main(null);
        } catch (InputMismatchException ex) {
            System.out.println("  Wrong input type! "+ ex);
        }
    }
    private static void circle() {
        try {
            System.out.println("  Enter dimensions of the following dimensions     ");
            System.out.print("  Radius:   ");
            double c = scan.nextDouble();
            Circle ObjCircle = new Circle (c);
            System.out.println(ObjCircle.areaAndPer());
            main(null);
        } catch (InputMismatchException ex) {
            System.out.println("  Wrong input type! "+ ex);
        }
    }
    private static void rectangle(){
        try {
            System.out.println("  Enter dimensions of the following dimensions     ");
            System.out.print("  Height:   ");
            double a = scan.nextDouble();
            System.out.print("  Length:   ");
            double b = scan.nextDouble();
            Rectangle ObjRectangle = new Rectangle (a, b);
            System.out.println(ObjRectangle.areaAndPer());
            main(null);
        } catch (InputMismatchException ex) {
            System.out.println("  Wrong input type! "+ ex);
        }
    }
    private static void sphere(){
        try {
            System.out.println("  Enter dimensions of the following dimensions     ");
            System.out.print("  Radius:   ");
            double c = scan.nextDouble();
            Sphere ObjSphere = new Sphere(c);
            System.out.println(ObjSphere.areaAndPer());
            main(null);
        } catch (InputMismatchException ex) {
            System.out.println("  Wrong input type!" + ex);
        }
    }
    private static void square() {
        try {
            System.out.println("  Enter dimensions of the following dimensions     ");
            System.out.print("  Side 1:   ");
            double a = scan.nextDouble();
            Square ObjSquare = new Square(a, a);
            System.out.println(ObjSquare.areaAndPer());
            main(null);
        } catch (InputMismatchException ex) {
            System.out.print("  Wrong input type!" + ex);
        }
    }
    private static void triangle() {
        try {
            System.out.println("  Enter dimensions of the following dimensions     ");
            System.out.print("  Height:   ");
            double a = scan.nextDouble();
            System.out.print("  Length:   ");
            double b = scan.nextDouble();
            System.out.print("  Side 2:   ");
            double d = scan.nextDouble();
            Triangle ObjTriangle = new Triangle(a, b, d);
            System.out.println(ObjTriangle.areaAndPer());
            main(null);
        } catch (InputMismatchException ex) {
            System.out.println("  Wrong input type!" + ex);
        }
    }
}
