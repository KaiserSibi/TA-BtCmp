public class Square extends Shapes{
    public Square(double height, double length){
        super(height, length);
    }

    public double areaSquare(){
        return (getHeight() * getLength());
    }

    protected double perSquare(){
        return (getHeight() * 4);
    }

    protected String areaAndPer(){
        return "  The area & perimeter of the Square is : " + areaSquare() + ", " + perSquare();
    }
}
