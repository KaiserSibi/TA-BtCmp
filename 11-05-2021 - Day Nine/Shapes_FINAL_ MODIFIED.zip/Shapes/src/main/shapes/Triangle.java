public class Triangle extends Shapes{
    public Triangle(double height, double length, double side2){
        super(height, length, side2);
    }

    protected double areaTriangle(){
        return ((getHeight() * getLength()) / 2);
    }

    protected double perTriangle(){
        return (getHeight() + getLength() + getSide2());
    }

    protected String areaAndPer(){
        return "  The area & perimeter of the Triangle is : " + areaTriangle() + ", " + perTriangle();
    }
}