package com.example.assignment.api.user.dao;

import com.example.assignment.api.loans.dao.Loans;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.ToString;

import javax.persistence.*;
import java.util.Set;
import java.util.UUID;

@Entity(name = "usercred")
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "usercred_id")
    private UUID id;
    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    @ToString.Include
    @Column(name = "first_name")
    private String firstName;
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    @ToString.Include
    @Column(name = "last_name")
    private String lastName;
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    @Column(name = "deposit_amount")
    private int depositAmount;
    public int getDepositAmount() { return depositAmount; }
    public void setDepositAmount(int depositAmount) { this.depositAmount = depositAmount; }

    @JsonIgnore
    @OneToMany
    @JoinTable(
            name = "usercred_loans",
            joinColumns = @JoinColumn(name = "usercred_id"),
            inverseJoinColumns = @JoinColumn(name = "loan_id"))
    private Set<Loans> loans;
}