package com.example.assignment.api.user.controller;

import com.example.assignment.api.user.dao.Users;
import com.example.assignment.api.user.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("api/vi/users")
public class UserController {
    private final UserService service;
    public UserController(UserService service) { this.service = service; }

    @GetMapping
    public List<Users> list() {
        return service.list();
    }

    @GetMapping("/{id}")
    public Optional<Users> get(@PathVariable UUID id) {
        return service.get(id);
    }

    @PostMapping
    public Users create(@RequestBody Users newUsers) {
        return service.create(newUsers);
    }

    @PutMapping("/{id}")
    public Users update(@PathVariable UUID id,
                        @RequestBody Users users) {
        return service.update(id, users);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable UUID id) {
        service.delete(id);
    }
}
