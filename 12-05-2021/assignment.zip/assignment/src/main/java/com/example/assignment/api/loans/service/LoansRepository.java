package com.example.assignment.api.loans.service;

import com.example.assignment.api.loans.dao.Loans;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.UUID;

public interface LoansRepository extends JpaRepository<Loans, UUID> {
    /*
    // @Query(value = "SELECT SUM(u.deposit_amount) FROM Users u")
    // int depositTotals();
    */
}
