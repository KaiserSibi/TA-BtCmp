package com.example.assignment.api.user.service;

import com.example.assignment.api.user.dao.Users;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    private final UserRepository repository;
    public UserServiceImpl(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Users> list() {
        return repository.findAll();
    }

    @Override
    public Users create(Users users) {
        return repository.save(users);
    }

    @Override
    public Users update(UUID id, Users users) {
        Users usersFromDB = repository.findById(id).orElseThrow();
        usersFromDB.setDepositAmount(users.getDepositAmount());
        usersFromDB.setFirstName(users.getFirstName());
        usersFromDB.setLastName(users.getLastName());
        return repository.save(usersFromDB);
    }

    @Override
    public void delete(UUID id) {
        repository.deleteById(id);
    }

    @Override
    public Optional<Users> get(UUID id) {
        return repository.findById(id);
    }
}
