package com.example.assignment.api.loans.dao;

import com.example.assignment.api.user.dao.Users;

import javax.persistence.*;
import java.util.UUID;


@Entity(name = "loans")
public class Loans {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "loan_id", nullable = false)
    private UUID id;
    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    @Column(name = "loan_amount")
    private int loanAmount;
    public int getLoanAmount() { return loanAmount; }
    public void setLoanAmount(int loanAmount) { this.loanAmount = loanAmount; }

    /*
        @JoinTable(
            name = "usercred_loans",
            joinColumns = @JoinColumn(name = "usercred_id"),
            inverseJoinColumns = @JoinColumn(name = "loan_id"))
    private Set<Loans> loans;
     */
    @ManyToOne
    @JoinColumn(name = "user_id")
    private Users users;
    public Users getUser() {
        return users;
    }
    public void setUser(Users users) {
        this.users = users;
    }
}