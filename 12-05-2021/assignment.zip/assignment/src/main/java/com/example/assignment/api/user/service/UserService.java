package com.example.assignment.api.user.service;

import com.example.assignment.api.user.dao.Users;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


public interface UserService {
    List<Users> list();
    Users create(Users users);
    Users update(UUID id, Users users);
    void delete(UUID id);
    Optional<Users> get(UUID id);
}