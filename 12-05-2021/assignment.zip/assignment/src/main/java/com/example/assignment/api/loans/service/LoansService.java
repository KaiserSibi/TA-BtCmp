package com.example.assignment.api.loans.service;

import com.example.assignment.api.loans.dao.Loans;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

public interface LoansService {
    List<Loans> list();
    Loans get(UUID id);
    Loans create(Loans loans);
}