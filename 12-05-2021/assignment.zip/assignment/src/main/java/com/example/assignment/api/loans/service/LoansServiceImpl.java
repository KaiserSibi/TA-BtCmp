package com.example.assignment.api.loans.service;

import com.example.assignment.api.loans.dao.Loans;
import com.example.assignment.api.user.service.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class LoansServiceImpl implements LoansService{
    private final LoansRepository repository;
    private final UserRepository userrepository;
    public LoansServiceImpl(LoansRepository repository, UserRepository userrepository) {
        this.repository = repository;
        this.userrepository = userrepository;
    }

    @Override
    public List<Loans> list() {
        return repository.findAll();
    }

    @Override
    public Loans create(Loans loan) {

        int x = userrepository.depositTotals();
        if (x > loan.getLoanAmount() && loan.getLoanAmount() % 1000 == 0){
            int y = loan.getLoanAmount() / 1000;
            loan.setLoanAmount(loan.getLoanAmount() - (100 * y));
            return repository.save(loan);
        } else {
            return null;
        }
    }

    @Override
    public Loans get(UUID id) {
        return repository.getById(id);
    }
}
