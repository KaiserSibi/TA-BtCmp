package com.example.assignment.api.loans.controller;


import com.example.assignment.api.loans.dao.Loans;
import com.example.assignment.api.loans.service.LoansService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("api/vi/loans")
public class LoansController {
    private final LoansService service;
    public LoansController(LoansService service) { this.service = service; }

    @GetMapping
    public List<Loans> list() { return service.list(); }

    @GetMapping("/{id}")
    public Loans get(@PathVariable UUID id) { return service.get(id); }

    @PostMapping
    public Loans create(@RequestBody Loans loans) { return service.create(loans); }

}
