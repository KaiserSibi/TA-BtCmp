package com.example.assignment.api.user.service;

import com.example.assignment.api.user.dao.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<Users, UUID> {
    @Query(value = "SELECT SUM(deposit_amount) FROM usercred", nativeQuery = true)
    int depositTotals();
}
