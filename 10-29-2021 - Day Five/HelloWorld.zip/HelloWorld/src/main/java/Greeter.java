public class Greeter {
    public String sayHello() {
        return "Hello world!";
    }
    public String sayGoodbye(){
        return "Goodbye!";
    }
}
