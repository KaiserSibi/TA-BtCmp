package com.demo.jpa.data;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Table(name = "\"position\"")
@Entity
@NamedQueries({
        @NamedQuery(name = "Position.DeleteById",
                query = "DELETE p FROM Position p WHERE p.position_id = :id")
})
public class Position {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @Column(name = "position_id", nullable = false)
    private Integer id;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "position_name", nullable = false)
    private String positionName;
    public String getPositionName() {
        return positionName;
    }
    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    @Column(name = "department", nullable = false)
    private String department;
    public String getDepartment() {
        return department;
    }
    public void setDepartment(String department) {
        this.department = department;
    }

    @Column(name = "min_salary")
    private Integer minSalary;
    public Integer getMinSalary() {
        return minSalary;
    }
    public void setMinSalary(Integer minSalary) {
        this.minSalary = minSalary;
    }

    @Column(name = "max_salary")
    private Integer maxSalary;
    public Integer getMaxSalary() {
        return maxSalary;
    }
    public void setMaxSalary(Integer maxSalary) {
        this.maxSalary = maxSalary;
    }

    public Position() { }

    public Position(Integer id, String positionName, String department, Integer minSalary, Integer maxSalary) {
        this.id = id;
        this.positionName = positionName;
        this.department = department;
        this.minSalary = minSalary;
        this.maxSalary = maxSalary;
    }
}