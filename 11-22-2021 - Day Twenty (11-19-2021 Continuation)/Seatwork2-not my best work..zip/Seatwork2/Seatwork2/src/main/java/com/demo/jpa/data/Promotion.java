package com.demo.jpa.data;

import javax.persistence.*;
import java.time.LocalDate;

@Table(name = "promotion")
@Entity
@NamedQueries({
        @NamedQuery(name = "Promotion.GetAllPromotions",
                //SELECT * FROM Data WHERE ID NOT IN (
                //    SELECT ID FROM Data JOIN Filter
                //       on Data.Name = Filter.Name and Data.Value <> Filter.Value
                query = "FROM Promotion f ORDER BY f.promotion_date WHERE f in (FROM Employee e WHERE e.emp_id = :id)") // ?
})
public class Promotion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "promotion_id", nullable = false)
    private Integer id;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    @ManyToOne
    @JoinColumn(name = "emp_id")
    private Employee emp;
    public Employee getEmp() {
        return emp;
    }
    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    @Column(name = "previous_position_id", nullable = false)
    private Integer previousPositionId;
    public Integer getPreviousPositionId() {
        return previousPositionId;
    }
    public void setPreviousPositionId(Integer previousPositionId) {
        this.previousPositionId = previousPositionId;
    }

    @Column(name = "new_promoted_position_id", nullable = false)
    private Integer newPromotedPositionId;
    public Integer getNewPromotedPositionId() {
        return newPromotedPositionId;
    }
    public void setNewPromotedPositionId(Integer newPromotedPositionId) {
        this.newPromotedPositionId = newPromotedPositionId;
    }

    @Column(name = "promotion_date")
    private LocalDate promotionDate;
    public LocalDate getPromotionDate() {
        return promotionDate;
    }
    public void setPromotionDate(LocalDate promotionDate) {
        this.promotionDate = promotionDate;
    }

    @Column(name = "new_salary")
    private Integer newSalary;
    public Integer getNewSalary() {
        return newSalary;
    }
    public void setNewSalary(Integer newSalary) {
        this.newSalary = newSalary;
    }

    public Promotion() { }

    public Promotion(Integer id, Employee emp, Integer previousPositionId, Integer newPromotedPositionId, LocalDate promotionDate, Integer newSalary) {
        this.id = id;
        this.emp = emp;
        this.previousPositionId = previousPositionId;
        this.newPromotedPositionId = newPromotedPositionId;
        this.promotionDate = promotionDate;
        this.newSalary = newSalary;
    }
}