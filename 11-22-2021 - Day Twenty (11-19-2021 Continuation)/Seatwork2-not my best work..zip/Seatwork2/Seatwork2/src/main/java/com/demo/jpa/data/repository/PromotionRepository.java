package com.demo.jpa.data.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

public class PromotionRepository {
    private EntityManager em;
    public PromotionRepository(EntityManager em) {
        this.em = em;
    }

    public void PromotionRepository(EntityManager em) {
        this.em = em;
    }

    public void getAllPromotions (Integer id) {
        Query query = em.createNamedQuery("Promotion.GetAllPromotions")
                .setParameter("id", id);
    }
}
