package com.demo.jpa.data;

import javax.persistence.*;
import java.time.LocalDate;

@Table(name = "project")
@Entity
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "project_id", nullable = false)
    private Integer id;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "project_name", nullable = false)
    private String projectName;
    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    @Lob
    @Column(name = "description")
    private String description;
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;
    public LocalDate getStartDate() {
        return startDate;
    }
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    @Column(name = "first_deployed", nullable = false)
    private LocalDate firstDeployed;
    public LocalDate getFirstDeployed() {
        return firstDeployed;
    }
    public void setFirstDeployed(LocalDate firstDeployed) {
        this.firstDeployed = firstDeployed;
    }

    public Project(Integer id, String projectName, String description, LocalDate startDate, LocalDate firstDeployed) {
        this.id = id;
        this.projectName = projectName;
        this.description = description;
        this.startDate = startDate;
        this.firstDeployed = firstDeployed;
    }
    public Project() { }
}