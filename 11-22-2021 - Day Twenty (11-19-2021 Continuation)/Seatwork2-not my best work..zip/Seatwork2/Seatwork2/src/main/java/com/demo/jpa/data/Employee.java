package com.demo.jpa.data;

import javax.persistence.*;
import java.time.LocalDate;

@Table(name = "employee")
@Entity
@NamedQueries({
        @NamedQuery(name = "Employee.findByName",
                query = "SELECT e FROM Employee e WHERE e.firstName = :fn AND e.lastName = :ln"),
        @NamedQuery(name = "Employee.findAll",
                query = "SELECT e FROM Employee e"),
                //query = "SELECT e FROM Employee INNER JOIN Promotion ON (Employee.emp_id = Promotion.emp_id")
                //query = "from Cat as fatcat where fatcat.weight > (select avg(cat.weight) from DomesticCat cat"
                //delete from Order order WHERE order.id IN (
                //    SELECT order.id FROM Order order
                //    JOIN order.credit credit
                //    WHERE credit.id in ?1)
                //query = "DELETE e FROM Employee e WHERE e.emp_id = " +
                //        "(SELECT p FROM Promotion p WHERE p.emp_id = :id)"),
        @NamedQuery (name = "Employee.updateByPromotion",
                query = "UPDATE Employee set position = :position AND set salary = :salary"),
        @NamedQuery(name = "Employee.updateLastNamebyId",
                query = "UPDATE Employee set lastName = :lastName WHERE id = :id"),
        @NamedQuery(name = "Employee.insertEmployee",
                query = "INSERT INTO Employee (lastName, firstName, salary, dateOfBirth, " +
                        "dateEmployed, position) " +
                        "SELECT lastName, firstName, salary, dateOfBirth, dateEmployed, position"),
        @NamedQuery(name = "Employee.deleteById",
                query = "DELETE FROM Employee WHERE id = :id")
})
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "emp_id", nullable = false)
    private Integer id;
    public Integer getId() { return id; }
    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "last_name", nullable = false)
    private String lastName;
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column(name = "first_name", nullable = false)
    private String firstName;
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name = "salary", nullable = false)
    private Integer salary;
    public Integer getSalary() {
        return salary;
    }
    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }
    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Column(name = "date_employed", nullable = false)
    private LocalDate dateEmployed;
    public LocalDate getDateEmployed() {
        return dateEmployed;
    }
    public void setDateEmployed(LocalDate dateEmployed) {
        this.dateEmployed = dateEmployed;
    }

    @ManyToOne
    @JoinColumn(name = "position_id")
    private Position position;
    public Position getPosition() {
        return position;
    }
    public void setPosition(Position position) {
        this.position = position;
    }

    @ManyToOne
    @JoinColumn(name = "promotion_id")
    private Promotion promotion;
    public Promotion getPromotion() {
        return promotion;
    }
    public void setPromotion(Promotion Promotion) {
        this.promotion = Promotion;
    }

    public Employee() { }

    public Employee(Integer id, String lastName, String firstName, Integer salary, LocalDate dateOfBirth,
                    LocalDate dateEmployed, Position position, Promotion promotion) {
        this.id = id;
        this.lastName = lastName;
        this.firstName = firstName;
        this.salary = salary;
        this.dateOfBirth = dateOfBirth;
        this.dateEmployed = dateEmployed;
        this.position = position;
        this.promotion = promotion;
    }
}