package com.demo.jpa.data.repository;

import com.demo.jpa.data.Employee;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

public class  EmployeeRepository {
    private EntityManager em;
    public EmployeeRepository(EntityManager em) {
        this.em = em;
    }

    public void listAllEmployees () {
        Query query = em.createNamedQuery("Employee.findAll");
        List results = query.getResultList();

        if (results != null && !results.isEmpty()) {
            results.forEach(emp -> {
                Employee empl = (Employee) emp;
                System.out.println(empl.getFirstName() + " " +
                        empl.getLastName() + ", a " +
                        empl.getPosition().getPositionName() +
                        " with a salary of " + empl.getSalary() +
                        " employed on " + empl.getDateEmployed());
            });
        }
    }

    public void employeeByName() {
        List<Employee> emp = em.createNamedQuery("Employee.findByName", Employee.class)
                .setParameter("fn", "John")
                .setParameter("ln", "Doe")
                .getResultList();

        if (emp != null && !emp.isEmpty()) {
            emp.forEach(empl ->
                    System.out.println(empl.getFirstName() + " " +
                            empl.getLastName() + ", a " +
                            empl.getPosition().getPositionName() +
                            " with a salary of " + empl.getSalary() +
                            " employed on " + empl.getDateEmployed())
            );
        }
    }

    public void updateByPromotion() {
        Query query = em.createNamedQuery("Employee.updateByPromotion")
                .setParameter("position", "position")
                .setParameter("salary", "100000");
        query.executeUpdate();
    }

    public void updateLastNamebyId() {
        Query query = em.createNamedQuery("Employee.updateLastNamebyId")
                .setParameter("lastName", "Doofus")
                .setParameter("id", "0000000");
        query.executeUpdate();
    }

    public void insertEmployee() {
        Query query = em.createNamedQuery("Employee.insertEmployee");
        query.executeUpdate();
    }

    public void deleteById() {
        Query query = em.createNamedQuery("Employee.deleteById")
                .setParameter("id", "100000");
        query.executeUpdate();
    }
}