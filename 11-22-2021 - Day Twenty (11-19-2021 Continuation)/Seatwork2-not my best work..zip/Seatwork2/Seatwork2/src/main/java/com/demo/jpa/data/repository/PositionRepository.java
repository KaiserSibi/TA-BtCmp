package com.demo.jpa.data.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

public class PositionRepository {
    private EntityManager em;
    public PositionRepository(EntityManager em) {
        this.em = em;
    }

    public void PositionRepository(EntityManager em) {
        this.em = em;
    }

    public void deletePosition (Integer id) {
        Query query = em.createNamedQuery("Position.DeleteById")
                .setParameter("id", id);
    }
}
