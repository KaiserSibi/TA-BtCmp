package com.demo.jpa.data;

import javax.persistence.*;
import java.time.LocalDate;

@Table(name = "project_team")
@Entity
public class ProjectTeam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "team_id", nullable = false)
    private Integer id;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    @ManyToOne(optional = false)
    @JoinColumn(name = "project_id", nullable = false)
    private Project project;
    public Project getProject() {
        return project;
    }
    public void setProject(Project project) {
        this.project = project;
    }

    @ManyToOne(optional = false)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee emp;
    public Employee getEmp() {
        return emp;
    }
    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    @Column(name = "projectlead", nullable = false)
    private Boolean projectlead = false;
    public Boolean getProjectlead() {
        return projectlead;
    }
    public void setProjectlead(Boolean projectlead) {
        this.projectlead = projectlead;
    }

    @Column(name = "active", nullable = false)
    private Boolean active = false;
    public Boolean getActive() {
        return active;
    }
    public void setActive(Boolean active) {
        this.active = active;
    }

    @Column(name = "date_started", nullable = false)
    private LocalDate dateStarted;
    public LocalDate getDateStarted() {
        return dateStarted;
    }
    public void setDateStarted(LocalDate dateStarted) {
        this.dateStarted = dateStarted;
    }

    public ProjectTeam() { }
    public ProjectTeam(Integer id, Project project, Employee emp, Boolean projectlead, Boolean active, LocalDate dateStarted) {
        this.id = id;
        this.project = project;
        this.emp = emp;
        this.projectlead = projectlead;
        this.active = active;
        this.dateStarted = dateStarted;
    }
}