import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.demo.jpa.data.repository.*;

public class App {
    private static EntityManager em;

    public static void main(String[] args) {
        Integer positionId = 1;
        Integer promotionId = 1000;
        EntityManagerFactory emf = Persistence
                .createEntityManagerFactory("studentPU");
        em = emf.createEntityManager();

        EmployeeRepository employeeRepository = new EmployeeRepository(em);
        System.out.println("Listing all employee info");
        employeeRepository.listAllEmployees();
        System.out.println("Listing employees with first name John: ");
        employeeRepository.employeeByName();

        PositionRepository positionRepository = new PositionRepository(em);

        positionRepository.deletePosition(positionId);

        PromotionRepository promotionRepository = new PromotionRepository(em);
        promotionRepository.getAllPromotions(promotionId);
    }
}