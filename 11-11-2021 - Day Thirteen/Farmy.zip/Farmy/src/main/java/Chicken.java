public class Chicken {
    public int getChickenEggs() {
        return (int)Math.floor(Math.random()*(120-80+1)+80);
    }
}
