import java.util.*;
import java.util.Collections;

public class Customer {
    private HashMap<String, Integer> CustomerList = new HashMap<>();

    protected HashMap<String, Integer> getCustomerList() {
        return CustomerList;
    }

    public static Map<String, Integer> sortByValueAsc(Map<String, Integer> map) {
        List<Map.Entry<String, Integer>> list = new LinkedList(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });

        Map<String, Integer> result = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }
}
