import java.util.*;

public class Homestead {
    public static void main(String[] args) {
        Chicken chicks = new Chicken();
        Customer cus = new Customer();
        HashMap<String, Integer> CustomerList = cus.getCustomerList();
        int dailyEggs, missingEggs = 0;

        for (int x = 1; x <= 5; x++){
            CustomerList.put("Customer" + x, 0);
        }


        Map<String,Integer> SortedCustomers = cus.sortByValueAsc(CustomerList);
        for (int x = 0; x <= 20; x++){
            dailyEggs = chicks.getChickenEggs();
            System.out.println("\nDay " + x);
            System.out.println("Produced Eggs: " + dailyEggs);

            for (Map.Entry<String, Integer> entry : SortedCustomers.entrySet()) {
                int eggs = entry.getValue();
                if (eggs == 20 * x && (dailyEggs > 20)){
                    SortedCustomers.compute(entry.getKey(), (key, val)
                            -> (val == null) ? 1 : val + 20);
                    dailyEggs -= 20;
                    System.out.println(entry.getKey() + " with " + entry.getValue()); // + " eggs! COND1 " + missingEggs + " | " + dailyEggs);
                } else {
                    if (eggs != 20 * x && (dailyEggs > 20)){
                        missingEggs = (20 * x) - entry.getValue();
                        final int fMissingEggs = missingEggs;
                        SortedCustomers.compute(entry.getKey(), (key, val)
                                -> (val == null) ? 1 : val + fMissingEggs + 20);
                        dailyEggs = (dailyEggs - missingEggs) - 20;
                        System.out.println(entry.getKey() + " with " + entry.getValue()); //+ " eggs! COND2 " + missingEggs + " | " + dailyEggs);
                    } else {
                        final int fDailyEggs = dailyEggs;
                        SortedCustomers.compute(entry.getKey(), (key, val)
                                -> (val == null) ? 1 : val + fDailyEggs);
                        missingEggs = 20 - dailyEggs;
                        dailyEggs = dailyEggs-dailyEggs;
                        System.out.println(entry.getKey() + " with " + entry.getValue()); // + " eggs! COND3 " + missingEggs + " | " + dailyEggs);
                    }
                }
            }
            System.out.println("Should be: " + 20 * (x + 1) + " | " + missingEggs);
            SortedCustomers = cus.sortByValueAsc(SortedCustomers);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}