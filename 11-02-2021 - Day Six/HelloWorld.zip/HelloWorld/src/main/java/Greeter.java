import java.util.Scanner;

public class Greeter {
    private String firstName;

    public String helloWorld(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String firstName = scanner.nextLine();
        return "Hello, " + firstName + "!";
    }
}
