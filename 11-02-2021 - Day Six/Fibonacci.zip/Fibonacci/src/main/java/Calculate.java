import java.util.Scanner;

public class Calculate {
    private int getNum() {
        int number;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of elements of the Fibonacci Sequence: ");
        number = scanner.nextInt();
        return number;
    }

    public String fibonnaciSequence() {
        int maxNum = getNum();
        int num1 = 0, num2 = 1;
        String generatedFibonacci = "0, " + num2;
        for(int x = 1; x < maxNum; ++x){
            int num3 = num1 + num2;
            generatedFibonacci = new StringBuilder().append(generatedFibonacci).append(", ").append(num3).toString();
            num1 = num2;
            num2= num3;
        }
        return generatedFibonacci;
    }
}
