public class Fibonacci {
    public static void main(String[] args) {
        Calculate fibonacci = new Calculate();
        System.out.println(fibonacci.fibonnaciSequence());
    }
}